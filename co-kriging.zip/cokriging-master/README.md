# cokriging
A MATLAB implementation of the co-kriging process using the DACE toolbox

These functions were used for the following AIAA SciTech Conference paper:

R. C. Kitson and C. E. S. Cesnik, “High speed vehicle fluid-structure-jet interaction analysis and modeling,” 58th AIAA/ASCE/AHS/ASC Structures, Structural Dynamics, and Materials Conference, AIAA 2017-0405, Jan. 2017, AIAA Structural Dynamics Best Student Paper.